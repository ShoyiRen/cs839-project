In this project stage, we acquired some news from websites of three countries(the United States, the United Kingdom and Cananda). All news we used are related to the PyeongChang 2018 Olympic Winter Games.
The entities we got from the document are the names of locations including continents, countries, states, cities, etc.(e.g. Europe, United States, California, PyeongChang). We also accepted the abbreviations such as US and UK. but we did not regard the adjectives as valid such as British, Canada`s and Korean.
We used the label pair <L></L> to identify the location name in all marked documents.
 
